#####################################################################################

Readme.txt file for EVS test sequences - March 2019

The test sequences for the EVS codec have a relevant size (1 799 996, 1 799 996 and 1 802 784 KBytes).
Then, they were not included inside the spec file 26444-g00.zip, but are stored at: 

ftp://ftp.3gpp.org/Specs/archive/26_series/26.444/test_sequences/ 

The filenames are:
26444_cc0_d70_e30_f10-TestSeq_BASOP_26442.zip (used for testing of TS 26.442)
26444_g10-TestSeq_BASOP_26452.zip (used for testing of TS 26.452)
26444_cb0_d70_e30_f10-TestSeq_Float_26443.zip (used for testing of TS 26.443)

Note that the files above will be updated with each new version of the EVS source code specs,
so that the corresponding version numbers of the related test sequences always match.

Contact:  
	Paolo Usai (SA 4 Technical Officer)/John Meredith (3GPP Specification Manager)
        ETSI
        paolo.usai@etsi.org / john.meredith@etsi.org 

######################################################################################


