/*====================================================================================
    EVS Codec 3GPP TS26.442 Nov 13, 2018. Version 12.12.0 / 13.7.0 / 14.3.0 / 15.1.0
  ====================================================================================*/

#ifndef __INCLUDED_DISCLAIMER_H
#define __INCLUDED_DISCLAIMER_H

#include <stdio.h>

int print_disclaimer(FILE *fPtr);




#endif /* __INCLUDED_DISCLAIMER_H */
